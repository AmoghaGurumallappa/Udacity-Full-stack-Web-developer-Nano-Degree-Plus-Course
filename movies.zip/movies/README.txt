Movie Trailer Website

This project is built by Python Programming

In the project folder "Movies" we have these files
1.Entertainment.py
2.Media.py
3.Fresh_tomatoes.py
4.filal output screenshot

In Entertainment.py file

- I have created the instance of the movies and gave values to it.
- And put all the movies name in the array. And called the open movie page function.
- I used print statement to show the name of the class used, doc type, and module i.e import libraries used.

In media.py

- Created the movie class and created two mothods __init__ and show_trailer
- __init__ is used to define the properties of the movie i.e storyline, poster of the movie and trailer url
- In show_trailer I used the oper web browser function to open the browser to play the trailer

In Fresh_tomaroes.py

- I have HTML tage to dispaly the poster and movie trailes information. 
- Used open movie page function to diaplay the movie trailer.

As soon as we run the code it will open the web browser which contain the movie name with the poster. If we click on the poster the movie trailer will play.